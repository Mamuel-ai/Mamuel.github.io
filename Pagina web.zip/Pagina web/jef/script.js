const loginForm = document.getElementById('login-form');
const errorMessage = document.getElementById('error-message');

loginForm.addEventListener('submit', function (e) {
    e.preventDefault();

    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;

    // Validación del formato de correo
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailPattern.test(email)) {
        errorMessage.textContent = 'Por favor ingrese un correo electrónico válido.';
        return;
    }

    // Validación de credenciales
    if (email === 'usuario@ejemplo.com' && password === '123456') {
        // Redirigir a la página de inicio si la autenticación es exitosa
        window.location.href = 'home.html';
    } else {
        errorMessage.textContent = 'Correo o contraseña incorrectos.';
    }
});

function openSidebar() {
    document.getElementById("sidebar").style.width = "250px";
}

function closeSidebar() {
    document.getElementById("sidebar").style.width = "0";
}

