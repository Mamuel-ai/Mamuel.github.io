function validateForm() {
    const email = document.getElementById("email").value;
    const password = document.getElementById("password").value;
    const role = document.getElementById("role").value;

    if (!email || !password || !role) {
        alert("Por favor, completa todos los campos.");
        return false; // Previene el envío del formulario si falta algún campo
    }

    // Simulación de inicio de sesión exitoso
    document.querySelector("main").style.display = "none";  // Ocultar formulario
    document.getElementById("lobby").style.display = "block";  // Mostrar lobby

    return false; // Prevenir el envío del formulario
}

function closeSession() {
    // Cerrar sesión, mostrar el formulario nuevamente
    document.querySelector("main").style.display = "flex";
    document.getElementById("lobby").style.display = "none";
}